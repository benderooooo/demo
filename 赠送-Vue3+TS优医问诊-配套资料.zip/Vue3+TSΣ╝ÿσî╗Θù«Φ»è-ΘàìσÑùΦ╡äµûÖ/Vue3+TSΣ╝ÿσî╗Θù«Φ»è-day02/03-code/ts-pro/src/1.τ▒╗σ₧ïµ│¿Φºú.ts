// TS CODE
export {}

// TypeScript类型注解

let msg: string

msg = 'this is message'

let count: number
count = 100

let isLading: boolean
isLading = false
