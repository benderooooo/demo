// TS CODE
export {}

// 数组类型注解
