var count = 100;
console.log(count);
