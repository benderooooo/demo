const count: number = 100

console.log(count)
