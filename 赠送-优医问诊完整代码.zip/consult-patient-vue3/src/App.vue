<script setup lang="ts"></script>

<template>
  <!-- 路由出口-一级路由 -->
  <router-view></router-view>
</template>

<style lang="scss" scoped></style>
